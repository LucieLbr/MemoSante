package fr.clalumo.memosante

class ResourcesModel(
    val name: String = "La COVID-19",
    val imgUrl: String = "https://www.designbolts.com/wp-content/uploads/2020/04/Covid-19-Free-Stock-Image-1.jpg",
    val lien: String="https://www.gouvernement.fr/info-coronavirus",

)
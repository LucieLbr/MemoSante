package fr.clalumo.memosante

class DocsModel (
    val name:String="Ordonnance pilule",
    val id:String="Doc1",
    val image:String="iebrfib"
        )
package fr.clalumo.memosante

class InfoModel (
    val id:String="patient0",
    val nam:String = "Claire",
    val age:String ="18",
    val firstname:String="Robidou"
)

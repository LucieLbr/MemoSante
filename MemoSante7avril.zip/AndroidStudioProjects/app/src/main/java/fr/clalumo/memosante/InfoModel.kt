package fr.clalumo.memosante

class InfoModel (
    val id:String="patient0",
    val name:String = "Claire",
    val age:String ="18",
    val firstname:String="Robidou",
    val blood:String="O+",
    val sex:String="Femme",
    val imageUrl:String="ebfob"
)

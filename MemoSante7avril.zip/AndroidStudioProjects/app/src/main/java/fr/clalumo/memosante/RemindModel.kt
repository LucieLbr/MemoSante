package fr.clalumo.memosante

class RemindModel (
    val id:String="rappel1",
    val name:String="Dentiste",
    val date:String="08 avril 2022",

    val day:String="07",
    val month:String="04",
    val year:String="2002",
    val hour:String="14",
        )
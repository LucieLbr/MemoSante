package fr.clalumo.naturecollection.adapter

class PlantItemDecoration {
    
}